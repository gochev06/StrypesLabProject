class EntityNotFoundException(Exception):
	pass