from dao.repository import Repository
from entity.customer import Customer
from util.func_utils import find_first


class CustomerRepository(Repository):

    def __init__(self, id_generator):
        super().__init__(id_generator)

    def find_by_pin(self, pin: int) -> Customer | None:
        return find_first(lambda x: x.pin == pin, self.find_all())

    def find_by_phone(self, phone: str) -> Customer | None:
        return find_first(lambda x: x.phone == phone, self.find_all())