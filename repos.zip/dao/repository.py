from typing import Iterator
from exception.entity_not_found_exception import EntityNotFoundException


class RepositoryIterator(Iterator):

	def __init__(self, iterable):
		self._next_index = 0
		self._values = list(iterable)

	def __next__(self):
		if self._next_index < len(self._values):
			result = self._values[self._next_index]
			self._next_index += 1
			return result
		raise StopIteration


class Repository:

	def __init__(self, id_generator, entities = {}):
		self._entities = entities
		self._id_generator = id_generator

	def __len__(self) -> int:
		return self.count()

	def __add__(self, other):
		self._entities.update(other._entities)
		return self

	def __iter__(self):
		# return iter(self._entities.values())
		# return RepositoryIterator(self._entities.values())
		# return RepositoryIterator(self)
		for entity in self._entities.values():
			yield entity

	def find_all(self):
		return self._entities.values()

	def find_by_id(self, id):
		found = self._entities.get(id)
		if found is None:
			raise EntityNotFoundException(f"Entity with ID: {id} not found")
		return found

	def create(self, entity):
		entity._id = self._id_generator.get_next_id()
		self._entities[entity._id] = entity
		return entity

	def update(self, entity):
		self.find_by_id(entity.id)
		self._entities[entity.id] = entity
		return entity

	def delete_by_id(self, id):
		old = self.find_by_id(id)
		del self._entities[id]
		return old

	def count(self):
		return len(self._entities)
