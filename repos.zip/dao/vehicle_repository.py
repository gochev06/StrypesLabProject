from dao.repository import Repository
from entity.vehicle import Vehicle
from util.func_utils import find_first


class VehicleRepository(Repository):

	def __init__( self, id_generator ):
		super().__init__(id_generator)

	def find_by_stock_no( self, first_name: str ) -> Vehicle | None:
		return find_first(lambda x: x.first_name == first_name, self.find_all())

	def find_by_vin( self, first_name: str ) -> Vehicle | None:
		return find_first(lambda x: x.first_name == first_name, self.find_all())
