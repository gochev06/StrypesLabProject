# Sale –
# Id: int,
# vehicle_stock_no: int[Vehicle[stock_no]],
# account_no: int[Customer[account_no]],
# sale_no: int,
# sale_type: string,
# sale_price: float


class Sale:

	def __init__( self, vehicle_stock_no, account_no, sale_no, sale_type, sale_price, id = None ):
		self._id = id
		self._vehichle_stock_no = vehicle_stock_no
		self._account_no = account_no
		self._sale_no = sale_no
		self._sale_type = sale_type
		self._sale_price = sale_price

	@property
	def sale_price(self):
		return self._sale_price
