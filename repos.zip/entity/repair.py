class Part:

	def __init__(self, description: str, price: float, quantity: int):
		self._description = description
		self._price = price
		self._quantity = quantity

	@property
	def total(self) -> float:
		return self._price * self._quantity



class Mechanic:

	def __init__(self, name: str, hours: int, rate: float):
		self._name = name
		self._hours = hours
		self._rate = rate

	@property
	def name(self) -> str:
		return self._name

	@property
	def total(self) -> float:
		return self._hours * self._rate


class Repair:

	def __init__(self, amount: float, service_date: str, vehicle_vin: str, part: Part, mechanic: Mechanic):
		self.amount = amount
		self.service_date = service_date
		self.vehicle_vin = vehicle_vin
		self.part = part
		self.mechanic = mechanic
		self.total_materials_price = part.total
		self.total_labor = mechanic.total
		self.total_paid = 0