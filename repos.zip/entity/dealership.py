# id(1): int,
# dealer_name: string,
# password: string,
# address_line_1: string,
# address_line_2: string,
# city: string,
# zip: int,
# country: string,
# phone: string,
# email: string


class Dealership:

	def __init__( self, _username: str, _password: str, _address_line_1: str, _city: str, _zip_code: int, _country: str,
	              _phone: str, _email: str, _budget: float, _address_line_2: str = None, _id: int = None ):
		self._id = _id
		self._username = _username
		self._password = _password
		self._address_line_1 = _address_line_1
		self._address_line_2 = _address_line_2
		self._city = _city
		self._zip_code = _zip_code
		self._country = _country
		self._phone = _phone
		self._email = _email
		self._budget = _budget

	def __repr__(self):
		line1 = f"| {self._id} | {self._username:20s} | {self._password:20s} | " \
		        f"{self._address_line_1:25s} | {self._city:10s} | {self._zip_code} " \
		        f"| {self._country:10s} | {self._budget:.2f} | {self._phone:15s} | {self._email:30s} |"
		len_line1 = len(line1) - 4
		line2 = f"| {self._email:^{len_line1}.{len_line1}s} |"
		return line1 + "\n" + line2

	def __str__( self ):
		return f'{self._id}) |{self._username} |{self._password} |{self._address_line_1} |{self._city}'

	def get_formatted_str( self ):
		return f'|{str(self._id):5s})| {self._username:10s} | {self._password:10s}|{self._city:15s} |'
