from entity.engine import Engine


# Vehicle –
# Id: int,
# stock_no: unique int,
# VIN: unique string,
# active: boolean,
# purchased_from(dropdown): list[string],
# body_color: string,
# built_year: int,
# make: string,
# model: string,
# type: # string
# new/used: list[string],
# purchase_date: date,
# wheels_type: list[string],
# mileage: int,
# style: string,
# Engine type: [
#     engine cylinders: int,
#     engine_capacity: float,
#     transmission: list[string],
#     fuel_type: list[string]
# ],
# other: [
#     purchase_price: float,
#     asked_price: float
# ],
# comments: textarea(text),
# Options(line cd player, 4x4, etc.): [a defined list of options(checkboxes)]
from entity.options import Options
from entity.vendor import Vendor


class Vehicle:

	def __init__( self, _stock_no: int, _vin: str, _active: bool, _purchased_from: Vendor, _body_color: str, _built_year: int,
	              _make: str, _model: str, _type: str, _new_used: str, _purchase_date: str, _wheel_color: str, _mileage: int,
	              _style: str, _engine: Engine, _purchase_price: float, _asked_price: float, _options: object = Options,
	              _id: int = None, _comments: str = None ) -> object:
		self._id = _id
		self._stock_no = _stock_no
		self._vin = _vin
		self._active = _active
		self._purchased_from = _purchased_from
		self._body_color = _body_color
		self._built_year = _built_year
		self._make = _make
		self._model = _model
		self._type = _type
		self._new_used = _new_used
		self._purchase_date = _purchase_date
		self._wheel_color = _wheel_color
		self._mileage = _mileage
		self._style = _style
		self._engine = _engine
		self._purchase_price = _purchase_price
		self._asked_price = _asked_price
		self._options = _options
		self._comments = _comments

	@property
	def stock_no(self):
		return self._stock_no

	@property
	def vin(self):
		return self._vin

	@property
	def make(self):
		return self._make

	@property
	def year(self):
		return self._built_year
	
	@property
	def model(self):
		return self._model

	def __str__(self):
		return f'{self._id}) |{self._stock_no} |{self._vin} |{self._make} |{self._model}'

	def get_formatted_str( self ):
		return f'|{str(self._id):5s}) | {str(self._stock_no):10s} | {str(self._purchased_from):10s}|{str(self._engine):15s} |{self._model:15s}'
