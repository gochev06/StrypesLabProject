# Customer –
#  Id: int,
# account_no: unique int,
# first_name: string,
# second_name: string,
# last_name: string,
# PIN: int,
# id_document_no: int,
# address: string,
# phone: string,
# email: string


class Customer:

	def __init__(self, first_name: str, last_name: str, address: str, phone: str, pin: int, id_document_no: int,
	             email: str, id = None, account_no: int = None, second_name: str = None):
		self._id = id
		self._account_no = account_no
		self._first_name = first_name
		self._second_name = second_name
		self._last_name = last_name
		self._pin = pin
		self._id_document_no = id_document_no
		self._address = address
		self._phone = phone
		self._email = email

	@property
	def account_no(self):
		return self._account_no
	@property
	def full_name(self):
		return f'{self._first_name} {self._last_name}'

	@property
	def pin(self):
		return self._pin

	def __str__(self):
		return f'{self._id}) |{self._account_no} |{self._first_name} |{self._last_name} |{self._pin}'

	def get_formatted_str( self ):
		return f'|{str(self._id)}) | {self._account_no} | {self._first_name:10s}|{self._pin:15d}'