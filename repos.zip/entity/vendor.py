# Vendor –
# name: string,
# vehicles: list[Vehicle],
# purchase_date: date



class Vendor:

	def __init__(self, _name):
		self._name = _name

	def __str__(self):
		return self._name