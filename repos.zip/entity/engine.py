class Engine:

	def __init__( self, _engine_cylinders: int, _engine_capacity: float):
		self._engine_cylinders = _engine_cylinders
		self._engine_capacity = _engine_capacity
		self._transmission = ['Manual', 'Automatic']
		self._fuel_type = ['Petrol', 'Diesel', 'LPG']

	def __str__(self):
		return f'{self._engine_cylinders}, {self._engine_capacity}'